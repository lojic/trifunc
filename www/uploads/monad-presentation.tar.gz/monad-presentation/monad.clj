;;
;; sample code to accompany the presentatios "If Monads are the answer,
;; what was the question?" presented to TriFunc.org, 3/10/2010
;;

;; each of the functions f,g,h has one numeric input, one numeric output
;; All can be composed in any order
(defn f [x] (+ x 1))
(defn g [x] (* x 3))
(defn h [x] (* x x))


;; create monitored versions of our functions
(defn monitored [func description]
     (fn [x] [(str description (func x)) (func x)]))

(def F (monitored f " +1 "))
(def G (monitored g " *3 "))
(def H (monitored h " sq "))

;; The monitored functions F, G, H, still have one numeric input
;; but each returns a 2-vector. Since outputs and inputs do not have the
;; same type, the monitored functions cannot be composed with one
;; another.

;; bind is used to fix the type mismatch and allow composition
(defn bind [monitored-func]
  (fn [ [desc-x x] ]
    (let [ [desc-y y] (monitored-func x) ]
      [(str desc-x desc-y) y])))

;; our new composition operator for F, G, H, and their progeny
;; in effect, F * G is (bind F).G 
(defn comp* [ & mon-funs]
  (letfn [(comp** [mf1 mf2]
                  (comp (bind mf1) mf2))]
    (reduce comp**
            (seq mon-funs))))


;; can compare the new vs the old functions by running something like
((comp  f g g h f f h) 5)
((comp* F G G H F F H) 5)

;;unit is the other half of the monad
(defn unit [x]
  ["" x])

;;--- Will do some randomized testing of conformance to monad laws

;; Code to construct random functions by composing f,g, and h
;; handy in contructing randomized tests...
(use '[clojure.contrib.seq-utils :only (rand-elt)])
(defn rand-sample [n population]
  (for [x (range 0 n)]
    (rand-elt population)))

(defn rand-fun [n funs]
  (apply comp (rand-sample n funs)))

;;lift gives nice way to state the morphism
;;lift defined in terms of unit, just as * is defined in terms of bind
(defn lift [func]
  (comp unit func))


;;---- Lift should preserve structure
;; claim:   lift f * lift g = lift (f . g)
;; same as: (comp* (lift f) (lift g)) = (lift (comp f g))
(defn agree?  [f g x]
"Test whether lift f * lift g = lift (f . g) by evaluating both at x and comparing."
  (= ( (lift (comp f g)) x)
     ( (comp* (lift f)
              (lift g))  x)))

;; Test the claim by using randomly generated test cases.
;; Should return true
(let [f1 (rand-fun 6 [f g h])
      f2 (rand-fun 7 [f g h])]
  (every? true?
          (map (partial agree? f1 f2)
               (range 10000))))


;;---- unit is the identity element for the * operator
;; claim:    F * unit = unit * F = F
;; same as:  (bind F) . unit = (bind unit) . F = F
;; same as:  (comp (bind F) unit) = (comp (bind unit) F) = F
;; same as:  (comp* F unit) = (comp* unit F) = F

(defn agree2? [f z]
  (let [msg "foobar"  ;;the string does not matter here
        F (fn [x] [msg (f x)])]
    (= ((comp* F unit) z)
       ((comp* unit F) z)
       (F z))))

;;Run the test using random function
;;Should return true
(let [test-fun (rand-fun 6 [f g h])]
  (every? true?
          (map (partial agree2? test-fun)
               (range 10000))))
